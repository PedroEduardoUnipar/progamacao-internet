/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.agenda;

/**
 *
 * @author pedro110500
 */
public class Agenda {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
