/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modulos;

/**
 *
 * @author pedro110500
 */
public class Endereco {
    private Integer id;
    private Integer nrRua;
    private String nomeRua;
    private String bairro;
    private String cidade;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNrRua() {
        return nrRua;
    }

    public void setNrRua(Integer nrRua) {
        this.nrRua = nrRua;
    }

    public String getNomeRua() {
        return nomeRua;
    }

    public void setNomeRua(String nomeRua) {
        this.nomeRua = nomeRua;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    @Override
    public String toString() {
        return "Endereco{" + "id=" + id + ", nrRua=" + nrRua + ", nomeRua=" + nomeRua + ", bairro=" + bairro + ", cidade=" + cidade + '}';
    }
    
}
