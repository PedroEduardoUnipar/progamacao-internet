/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modulos;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 *
 * @author pedro110500
 */
public class Agenda {
    private Integer id;
    private ArrayList<Contatos> contatos = new ArrayList<>();

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public ArrayList<Contatos> getContatos() {
        return contatos;
    }

    public void addContatos(ArrayList<Contatos> contatos) {
        this.contatos = contatos;
    }
    

}
