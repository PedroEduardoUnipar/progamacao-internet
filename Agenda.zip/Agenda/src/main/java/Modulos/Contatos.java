/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modulos;

import java.util.ArrayList;

/**
 *
 * @author pedro110500
 */
public class Contatos {
    private Integer id;
    private String nome;
    private ArrayList<Endereco> endereco = new ArrayList<>();
    private ArrayList<Telefone> telefone = new ArrayList<>();
    
    
    
    
    
}
