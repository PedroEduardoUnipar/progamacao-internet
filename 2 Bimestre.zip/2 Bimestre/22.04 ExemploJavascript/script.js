let titulo = document.querySelector ("#titulo");
let campotexto = document.querySelector ("#campotexto")
let bttrocartexto = document.querySelector ("#bttrocartexto")
let btresetartexto = document.querySelector ("#btresetartexto")
let soma = document.querySelector ("#soma")
let num1 = document.querySelector ("#num1")
let num2 = document.querySelector ("#num2")
let resultadosoma = document.querySelector ("#resultadosoma")
let valpago = document.querySelector ("#valpago")
let valproduto = document.querySelector ("#valproduto")
let trocobt = document.querySelector ("#trocobt")
let resultadotroco = document.querySelector ("#resultadotroco")
 
    function alterarTexto(){
        //retirando o valor digitado no input
        //e jogando na variavel
        let textodigitado = campotexto.value;
        
        //Atribuindo ao elemento titulo o texto que foi digitado
        //No input
        titulo.textContent = textodigitado;
    } 
//atribuindo uma ação de clicar no botao
bttrocartexto.onclick = function (){
    alterarTexto(); 
}
    function resettexto(){
        let textoresetado = "Hello World !!";

        titulo.textContent = textoresetado;
    }
btresetartexto.onclick = function(){
    resettexto();
}
    function somanumeros (){
    let numero1 = Number(num1.value);
    let numero2 = Number(num2.value);

        let somanumeros = numero1 + numero2 ;

        resultadosoma.textContent = somanumeros;
    }
    soma.onclick = function(){
        somanumeros ();
    }
    function troco () {
        let valorpago = Number(valpago.value);
        let valorproduto = Number(valproduto.value);

        let troco = valorpago - valorproduto;

        resultadotroco.textContent = troco;
    }
  
    trocobt.onclick = function(){
    troco();
 }
