let dia  = document.querySelector ("#dia")
let mes  = document.querySelector ("#mes")
let btt  = document.querySelector ("#btt")
let result  = document.querySelector ("#result")

function diadoano(){
    let diadomes = Number (dia.value)
    let mesdoano = Number (mes.value)

    let diadoano = (mesdoano*30)+diadomes

    result.textContent = "Hoje é o dia "+diadoano+" Do Ano"
}

btt.onclick = function (){
    diadoano()
}