let qtcavalos =  document.querySelector ("#qtcavalos")
let bttcalc =  document.querySelector ("#bttcalc")
let result =  document.querySelector ("#result")


function calcular(){
    let ferraduras = qtcavalos.value*4

    result.textContent = ferraduras
}
bttcalc.onclick = function(){
    calcular()
}