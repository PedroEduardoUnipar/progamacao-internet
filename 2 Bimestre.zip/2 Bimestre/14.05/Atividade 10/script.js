let  dias = document.querySelector ("#dias")
let btt  = document.querySelector ("#btt")
let result  = document.querySelector ("#result")
let result2  = document.querySelector ("#result2")




function calc(){
    diastotais = Number (dias.value)
    anos = Math.floor (diastotais/365)
    restodias = diastotais%365
    meses = Math.floor(restodias/30)
    restadias = restodias%30

    result.textContent = diastotais +"Dias Equivalem A "+anos+"Anos"+meses+"Meses"+restadias+"Dias"
    result2.textContent = restodias
}

btt.onclick = function (){
    calc()
}