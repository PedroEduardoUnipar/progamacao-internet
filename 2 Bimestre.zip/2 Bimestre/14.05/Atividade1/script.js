let largura = document.querySelector ("#largura")
let altura = document.querySelector ("#altura")
let exiba = document.querySelector ("#exiba")
let areaterreno = document.querySelector ("#areaterreno")




function calculararea () {
let area = largura.value*altura.value

areaterreno.textContent = "A area do terreno sera "+area+"M²"
}

exiba.onclick = function(){
    calculararea()
}

