let rsgas = document.querySelector ("#rsgas")
let rs = document.querySelector ("#rs")
let btt = document.querySelector ("#btt")
let result = document.querySelector ("#result")


function calculargas (){
let gas = Number (rsgas.value)
let reais = Number (rs.value)

let gasporrs = reais/gas

result.textContent = "Voce Consegue Abastecer "+gasporrs+" Litros"

}

btt.onclick = function (){
    calculargas()
}