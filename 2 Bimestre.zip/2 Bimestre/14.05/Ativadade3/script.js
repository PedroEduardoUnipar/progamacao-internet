let paezinhos = document.querySelector ("#paezinhos")
let broas = document.querySelector ("#broas")
let btt = document.querySelector ("#btt")
let arrecadou = document.querySelector ("#arrecadou")
let quardar = document.querySelector ("#quardar")

function quantovendi(){
    let valorpaezinhos = paezinhos.value*0.12
    let valorbroas = broas.value*1.5
    let arrecadado = valorpaezinhos+valorbroas

    arrecadou.textContent = "A Hotpão Arrecadou "+"R$"+arrecadado 
   
    return arrecadado
}

btt.onclick = function (){
  
    guardar()
}

function guardar (){
    
    let valor = quantovendi()/100*10
    

    quardar.textContent = "Devera Ser Guardado na poupança "+"R$"+ valor 
}