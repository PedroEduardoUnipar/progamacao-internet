let p  = document.querySelector ("#p")
let m  = document.querySelector ("#m")
let g  = document.querySelector ("#g")
let  btt = document.querySelector ("#btt")
let  result = document.querySelector ("#result")

function calcularvalor(){
    let pequeno = Number (p.value)
    let medio = Number (m.value)
    let grande = Number (g.value)

    let pequenovalue = pequeno*10
    let mediovalue = medio*12
    let grandevalue = grande*15

    let resultado = pequenovalue+mediovalue+grandevalue

    result.textContent = "Valor Da Compra É "+resultado
}

btt.onclick = function (){
    calcularvalor()
}