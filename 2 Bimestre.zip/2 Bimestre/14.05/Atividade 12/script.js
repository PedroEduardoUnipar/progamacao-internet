let numero  = document.querySelector ("#numero")
let btt  = document.querySelector ("#btt")
let centena  = document.querySelector ("#centena")
let  dezena = document.querySelector ("#dezena")
let unidade  = document.querySelector ("#unidade")






function calc(){
let num = Number (numero.value)

let calccentena = Math.floor (num/100)
let calcdezena = Math.floor ((num % 100)/10)
let calcunidade = Math.floor (num %10)

centena.textContent = calccentena;
dezena.textContent = calcdezena;
unidade.textContent = calcunidade;
}

btt.onclick = function (){
calc()
}