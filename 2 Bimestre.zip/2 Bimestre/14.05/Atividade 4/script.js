let name = document.querySelector ("#name")
let age = document.querySelector ("#age")
let btt = document.querySelector ("#btt")
let result = document.querySelector ("#result")


function calcularidade (){

let idade = Number (age.value)

result.textContent = name.value+" VOCE JA VIVEU "+(idade*365)+" DIAS"

}

btt.onclick = function(){
    calcularidade()
}
