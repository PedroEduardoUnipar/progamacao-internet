let tamanho  = document.querySelector ("#tamanho")
let resultado  = document.querySelector ("#resultado")
let btt = document.querySelector ("#btt")


function calc(){
    let raio = Number (tamanho.value)

    let pi = raio*raio
    let calc = (pi*3.14)

    resultado.textContent = calc
    
    
}


btt.onclick = function (){
    calc()
}