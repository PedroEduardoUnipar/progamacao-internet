let xA  = document.querySelector ("#xA")
let yA  = document.querySelector ("#yA")
let  xB = document.querySelector ("#xB")
let  yB = document.querySelector ("#yB")
let btt  = document.querySelector ("#btt")
let  result = document.querySelector ("#result")



function calcular (){
    
    numberxA = Number (xA.value)
    numberyA = Number (yA.value)
    numberxB = Number (xB.value)
    numberyB = Number (yB.value)

    numberX = (numberxA-numberxB)
    numberY = (numberyA-numberyB)
    calcX = numberX*numberX
    calcY = numberY*numberY
    calcXY = calcX+calcY

    raizquadrada = Math.sqrt(calcXY)

    result.textContent = raizquadrada
}

btt.onclick = function (){
    calcular()
}