let valor  = document.querySelector ("#valor")
let btt  = document.querySelector ("#btt")
let resultado  = document.querySelector ("#resultado")


function calcular(){
    let conta = Number (valor.value)

    let parteinteira = Math.floor (conta/3)
    let carlos = Math.floor (parteinteira)
    let andre = Math.floor (parteinteira)
    let felipe = (conta -(andre+carlos))





    resultado.textContent = "Carlos Paga"+carlos+"/"+"Andre Paga"+andre+"/"+"felipe Paga"+felipe
}

function test(){
    resultado.textContent = "test"
}

btt.onclick = function(){
    calcular()
}