let quilo  = document.querySelector ("#quilo")
let  result = document.querySelector ("#result")
let  btt = document.querySelector ("#btt")

function calcularprato(){
    let peso = Number (quilo.value)
    let pesoporquilo = peso*12

    result.textContent = pesoporquilo
}
btt.onclick = function (){
    calcularprato()
}