let  primeirovalor  = document.querySelector ("#primeirovalor")
let segundovalor = document.querySelector ("#segundovalor")
let calcular = document.querySelector ("#calcular")
let resultado = document.querySelector ("#resultado")
let mprimeiro = document.querySelector ("#mprimeiro")
let msegundo = document.querySelector ("#msegundo")
let mterceiro = document.querySelector ("#mterceiro")
let bttm = document.querySelector ("#bttm")
let mquarto = document.querySelector ("#mquarto")
let resultadom = document.querySelector ("#resultadom")
let imparpar = document.querySelector ("#imparpar")
let bttimparpar = document.querySelector ("#bttimparpar")
let resultadoimparpar = document.querySelector ("#resultadoimparpar")


function test (){
    resultado.textContent = primeirovalor.value
}

function qualmaior (){
    let primeiroval = Number (primeirovalor.value)
    let segundoval = Number (segundovalor.value)
    let result
    if (primeiroval > segundoval){
        result = "o meior numero é"+ primeiroval
    }
    else {
        result = "o meior numero é" + segundoval
    }
    resultado.textContent = result
}

calcular.onclick = function (){
    qualmaior()
}

function qualmenor (){
    let num1 = Number (mprimeiro.value)
    let num2 = Number (msegundo.value)
    let num3 = Number (mterceiro.value)
    let num4 = Number (mquarto.value)
    let result
    if (num1<num2 && num1<num3 && num1<num4){
        result = num1
    }
    else if (num2<num1 && num2<num3 && num2<num4){
        result = num2
    }
    else if (num3<num1 && num3<num2 && num3<num4){
        result = num3
    }
    else {
        result = num4
    }
    resultado = Number (result)

    resultadom.textContent = "O Menor Numero é "+ resultado
}

bttm.onclick = function (){
    qualmenor()
}

function ImparPar () {
    let imparoupar = Number (imparpar.value)
    if(imparoupar % 2 === 0){
        imparoupar = "Par"
    }
    else{
        imparoupar = "Impar"
    }
    resultadoimparpar.textContent = imparoupar
}

bttimparpar.onclick = function (){
    ImparPar()
}