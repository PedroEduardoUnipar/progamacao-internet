let salario  = document.querySelector ("#salario")
let btt  = document.querySelector ("#btt")
let antesaumento  = document.querySelector ("#antesaumento")
let depoisaumento  = document.querySelector ("#depoisaumento")
let comimposto  = document.querySelector ("#comimposto")

function calc(){
let salariobruto = Number (salario.value)

aumento = salariobruto/100*15+salariobruto
imposto = aumento-(aumento/100*8)

antesaumento.textContent = salariobruto
depoisaumento.textContent = aumento
comimposto.textContent = imposto

}

btt.onclick = function (){
    calc()
}