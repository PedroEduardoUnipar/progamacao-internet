let codigo = document.querySelector ("#codigo")
let quantidade = document.querySelector ("#quantidade")
let calcularLanche = document.querySelector ("#calcularLanche")
let resLanche = document.querySelector ("#resLanche")
let saldo = document.querySelector ("#saldo")
let bttcalcular = document.querySelector ("#bttcalcular")
let resCredito = document.querySelector ("#resCredito")



function calccreditobancario (){
    let saldomedio = Number (saldo.value)
    if (saldomedio<200){
        resCredito.textContent="Nenhum Crédito"
    }
    else if (saldomedio<400){
        resCredito.textContent = "seu Limite é "+(saldomedio/100*20)
    }
    else if (saldomedio<600){
        resCredito.textContent = "Seu Limite é "+(saldomedio/100*30)
    }
    else {resCredito.textContent = "Seu Limite é "+(saldomedio/100*40)}
    }
   

bttcalcular.onclick = function(){
    calccreditobancario()
}

function calcularpedido (){
    let selecao = codigo.value
    let quantidadepedido = Number (quantidade.value)
    if (selecao == "Cachorro Quente"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*11)
    }
    else if (selecao == "Bauru"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*8.5)
    }
    else if (selecao == "Misto Quente"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*8)
    }
    else if (selecao == "Hamburguer"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*9)
    }
    else if (selecao == "Cheeseburger"){
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*10)
    }
    else {
        resLanche.textContent = "Seu Pedido deu R$:"+(quantidadepedido*4.5)
    }

}

calcularLanche.onclick = function (){
    calcularpedido ()
}