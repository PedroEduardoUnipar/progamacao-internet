let inputdolar = document.querySelector ("#inputdolar")
let um = document.querySelector ("#um")
let dois = document.querySelector ("#dois")
let cinco = document.querySelector ("#cinco")
let dez = document.querySelector ("#dez")
let btt = document.querySelector ("#btt")
let egg = document.querySelector ("#egg")
let inputegg = document.querySelector ("#inputegg")
let chease = document.querySelector ("#chease")
let bttegg = document.querySelector ("#bttegg")
let calcum = document.querySelector ("#calcum")
let result = document.querySelector ("#result")
let calcdois = document.querySelector ("#calcdois")
let mais = document.querySelector ("#mais")
let menos = document.querySelector ("#menos")
let mult = document.querySelector ("#mult")
let div = document.querySelector ("#div")
let sbum = document.querySelector ("#sbum")
let sbdois = document.querySelector ("#sbdois")
let sbtres = document.querySelector ("#sbtres")
let sbquatro = document.querySelector ("#sbquatro")
let rf = document.querySelector ("#rf")
let valorped = document.querySelector ("#valorped")
let sabores = document.querySelector ("#sabores")
let pedir = document.querySelector ("#pedir")



function calcdolar (){
    let valordolar = Number (inputdolar.value)
    let valorumperc = 1/100*valordolar+valordolar
    let valordoisperc= 2/100*valordolar+valordolar
    let valorcincoperc= 5/100*valordolar+valordolar
    let valordezperc= 10/100*valordolar+valordolar
     
    um.textContent = valorumperc
    dois.textContent = valordoisperc
    cinco.textContent = valorcincoperc
    dez.textContent = valordezperc
    
}

btt.onclick = function(){
    calcdolar ()

}

function calcomelete () {
    let pessoas= Number (inputegg.value)
    let qteggp = 2
    let qtchease = 50

    calcegg = pessoas*qteggp
    calcchease = pessoas*qtchease

    egg.textContent = calcegg
    chease.textContent = calcchease
}

bttegg.onclick = function (){
    calcomelete()
}

function calculo (){
    numeroum = Number (calcum.value)
    numerodois = Number (calcdois.value)

    soma = numeroum+numerodois
    subtração = numeroum-numerodois
    multiplicação = numeroum*numerodois
    divisao = numeroum/numerodois

    mais.textContent = soma
    menos.textContent = subtração
    mult.textContent = multiplicação
    div.textContent = divisao
}

result.onclick = function() {
    calculo()
}
function CalculoPizza (){
    let refrigerante = Number (rf.value)
    calcrefri = refrigerante*7
    calcpizza = 48+calcrefri

    sabores.textContent = sbum.value+","+sbdois.value+","+sbtres.value+","+sbquatro.value
    valorped.textContent = calcpizza
}

pedir.onclick = function(){
    CalculoPizza()
}
