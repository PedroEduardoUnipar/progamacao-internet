let rota = document.querySelector ("#rota")
let rote = document.querySelector ("#linha")
let src = document.querySelector ("#src")


function srcrota (){
    let procurarota = rota.value

    linha.textContent = procurarota
}

src.onclick = function (){
    srcrota()
}