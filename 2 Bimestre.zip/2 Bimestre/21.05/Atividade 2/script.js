let  ano = document.querySelector ("#ano")
let btt  = document.querySelector ("#btt")
let  idade = document.querySelector ("#idade")




function calcularidade(){
let Ano = Number (ano.value)
let difano = 2025-Ano
    if (difano < 12){
        difano = "Infantil"
    }
    else if (difano < 17){
        difano = "Adolescente"
    }   
    else if (difano < 59){
        difano = "Adulto"
    }
    else {
        difano = "Sênior"
    }

    idade.textContent = difano
}

btt.onclick =  function(){
    calcularidade()
}