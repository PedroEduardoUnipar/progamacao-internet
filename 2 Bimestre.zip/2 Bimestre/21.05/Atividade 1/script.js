let peso  = document.querySelector ("#peso")
let altura  = document.querySelector ("#altura")
let btt  = document.querySelector ("#btt")
let  imc = document.querySelector ("#imc")

function calcularimc(){
    let Peso = Number (peso.value)
    let Altura = Number (altura.value)

    let alturaaoquadrado = Altura*Altura
    let calculoimc =   Peso/alturaaoquadrado

    if (calculoimc < 18.5){
        calculoimc = "Abaixo do peso"
    }
    else if (calculoimc < 24.9){
        calculoimc = "Normal"
    }
    else if (calculoimc < 29.9){
        calculoimc = "Sobrepeso"
    }
    else if (calculoimc < 34.9){
        calculoimc ="Obesidade Grau I"
    }
    else if (calculoimc < 39.9){
        calculoimc = "Obesidade Grau II"
    }
    else {
        calculoimc = "Obesidade Grau III"
    }


    imc.textContent = calculoimc


}

btt.onclick = function (){
    calcularimc()
}