let valuenic  = document.querySelector ("#valuenic")
let jurosmes  = document.querySelector ("#jurosmes")
let  meses = document.querySelector ("#meses")
let btt  = document.querySelector ("#btt")
let  result = document.querySelector ("#result")

function calcularjuroscomposto (){
let Valorinicial = Number (valuenic.value)
let jurospormes = Number (jurosmes.value)
let qtmeses = Number (meses.value)
let calculojurosperc = jurospormes/100

let calculojuros = 1+calculojurosperc
let calculojurosano = Math.pow(calculojuros,qtmeses)
let calculojurostotal = Valorinicial*calculojurosano


result.textContent = calculojurostotal.toFixed(2)
}
btt.onclick = function (){
    calcularjuroscomposto()
}