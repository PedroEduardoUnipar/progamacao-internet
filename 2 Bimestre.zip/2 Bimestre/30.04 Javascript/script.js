let kg = document.querySelector ("#kg")
let rskg = document.querySelector ("#rskg")
let pagamento = document.querySelector ("#pagamento")
let bttkg = document.querySelector ("#bttkg")
let saldobtt = document.querySelector ("#saldobtt")
let saldo = document.querySelector ("#saldo")
let saldo1perc = document.querySelector ("#saldo1perc")
let num1 = document.querySelector ("#num1")
let num2 =  document.querySelector ("#num2")
let num3 = document.querySelector ("#num3")
let MAritimetica = document.querySelector ("#MAritimetica")
let MPonderada = document.querySelector ("#MPonderada")
let SomaMedia = document.querySelector ("#SomaMedia")
let MediaMedia = document.querySelector ("#MediaMedia")
let calcular = document.querySelector ("#calcular")


function pesarkg () {
    let valorquilo = Number (rskg.value)
    let quilo = Number (kg.value)
    let total = valorquilo * quilo 

    pagamento.textContent = total
}

bttkg.onclick = function(){
    pesarkg()
}

function calculosaldo(){
    let saldocon = Number (saldo.value)
    let saldoa = 1/100*saldocon
    let saldototal = saldocon + saldoa


    saldo1perc.textContent = saldototal
}
saldobtt.onclick = function(){
    calculosaldo()
}
function calcmediaa (){
    let numero1 = Number (num1.value)
    let numero2 = Number (num2.value)
    let numero3 = Number (num3.value)
    calc = numero1 + numero2 + numero3
     let mediaa = calc/3

    MAritimetica.textContent = mediaa
    return mediaa
}
calcular.onclick = function (){
    calcmediaa();
    calcmediap();
    somamedias()
}
function calcmediap (){
    let numero1 = Number (num1.value)
    let numero2 = Number (num2.value)
    let numero3 = Number (num3.value)
    calc = numero1*3 + numero2*2 + numero3*5
    let calp = 3+2+5
    let mediap = calc/calp

    MPonderada.textContent = mediap
    return mediap;
}

function somamedias (){
    let mediadois = (calcmediap()) + (calcmediaa())
    let resulmediadois = mediadois/2

    SomaMedia.textContent = mediadois
    MediaMedia.textContent = resulmediadois
}
