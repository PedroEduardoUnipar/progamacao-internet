/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Telefone {
    String marca;
    String modelo;
    boolean estadoTelefone;
    boolean emChamada;
    
    
    void ligarSmartphone(){
        estadoTelefone = true;
        System.out.println("O Telefone Esta Ligado");}
    void desligarSmartphone(){
        estadoTelefone = false;
        System.out.println("O Telefone Esta Desligado");}
      void ligarParaContato(String contato) {
        if (estadoTelefone) {
            emChamada = true;
            System.out.println("Ligando para " + contato + "...");
        } else {
            System.out.println("Telefone desligado. Não é possível ligar.");
        }
    }
    void desligarChamada(){
        if (estadoTelefone && emChamada){
            System.out.println("chamada desligada");
            emChamada = false;}}
    
    void imprimir(){
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Telefone ligado? " + estadoTelefone);
        System.out.println("Em chamada? " + emChamada);
        System.out.println("----------------------------");}
                    
    
    
    
    
    
    
    
    
    
    
    
}
