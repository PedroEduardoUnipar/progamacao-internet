/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Gato {
    String nome;
    String raca;
    Integer idade;
    Integer peso;
    String cor;
}
