/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Geladeira {
    Boolean ligado;
    Boolean portaFechada;
    String estaligado;
    String validarporta;
    
void imprimir(){
    if (ligado = true) {
        estaligado = "Ligada";}
    else {estaligado = "Desligada";}
    if (portaFechada = true){
        validarporta = "Aberta";}
    else {validarporta = "Fechada";}
    System.out.println("A Geladeira Esta:"+estaligado);
    System.out.println("A Porta Esta:"+validarporta);
}
}

