/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Televisor {
    Boolean ligado;
    Integer canal;
    Integer volume;
    Integer numeroCanais;
    Integer volumeMaximo;
    
    void ligar(){
        ligado = true;}
    void desligar(){
        ligado = false;}
    void aumentarVolume(){    
        if (ligado && volume < volumeMaximo){
            volume++;}}
    void abaixarVolume(){
        if (ligado && volume > 0){
            volume--;}}
    void alterarCanalParaCima(){
        if (ligado && canal < numeroCanais){
            canal++;}}
    void alterarCanalParaBaixo(){
        if (ligado && canal < 0){
            canal--;}}
    void imprimir(){
        if(ligado){
        System.out.println("Canal:"+canal);
        System.out.println("Volume:"+volume);}}
}
    
    
    
    
    
    
 
