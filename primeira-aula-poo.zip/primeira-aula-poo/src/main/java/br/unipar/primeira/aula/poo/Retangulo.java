/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Retangulo {
    Double  comprimento;
    Double largura;
    Double area;
    Double perimetro;
    
    
    public void calcularArea(){
    area = comprimento*largura;
    }

public void calcularPerimetro(){
        perimetro = 2*(comprimento+largura);
}
void imprimir(){
       System.out.println("Comprimento: " + comprimento);
        System.out.println("Largura: " + largura);
        System.out.println("Área: " + area);
        System.out.println("Perímetro: " + perimetro);
    }
}







