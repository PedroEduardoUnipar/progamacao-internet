/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class PrimeiraAulaPoo {

    public static void main(String[] args) {
       Aluno aluno = new Aluno();
        aluno.nome = "pedro";
                aluno.ra = 60009605;
                aluno.idade = 25;
                aluno.telefone = 45991411276L;
                
       Aluno aluno2 = new Aluno();
        aluno.nome = "matheus";
                aluno.ra = 999999999;
                aluno.idade = 25;
                aluno.telefone = 45991411276L;
        
            
        Retangulo retangulo = new Retangulo();

        retangulo.comprimento = 5d;
        retangulo.largura = 3d;

        retangulo.calcularArea();
        retangulo.calcularPerimetro();
        retangulo.imprimir();
        
        Geladeira geladeira = new Geladeira();
        geladeira.ligado = true;
        geladeira.portaFechada = true;
        
        geladeira.imprimir();
        
        Televisor televisor = new Televisor();
        televisor.desligar();
        televisor.numeroCanais = 5;
        televisor.volumeMaximo = 10;
        televisor.canal = 1;
        televisor.volume = 0;
        televisor.aumentarVolume();
        televisor.desligar();
        televisor.alterarCanalParaCima();
        televisor.imprimir();
        
        
        Cachorro cachorro = new Cachorro();
        cachorro.vivo = true;
        cachorro.nome = "tobi";
        cachorro.idade = 5;
        cachorro.deitar();
        cachorro.latir();
        cachorro.uivar();
        cachorro.rolar();
        
        
        Telefone t = new Telefone();

        t.marca = "Samsung";
        t.modelo = "Galaxy S21";

        t.ligarSmartphone();
        t.ligarParaContato("pedro");
        t.imprimir();

        t.desligarChamada();
        t.desligarSmartphone();
        t.imprimir();
        
        
        
        
        
        
        
        
    }
    
  
    
    
}

