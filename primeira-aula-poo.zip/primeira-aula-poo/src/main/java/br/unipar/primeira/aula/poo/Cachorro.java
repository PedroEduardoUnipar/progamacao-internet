/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.unipar.primeira.aula.poo;

/**
 *
 * @author pedro110500
 */
public class Cachorro {
    String nome;
    Boolean vivo;
    Integer idade;
    
    void latir(){
        if (vivo){
        System.out.println(nome+":Au-Au");}
    }
    void uivar(){
        if(vivo){
            System.out.println(nome+":Auuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuu");}
    }
    
   void deitar(){
       if(vivo){
           System.out.println("__");}}
   void rolar(){
       if(vivo){
       System.out.println("/o/\\o\\/o/");}}
    
    
    
    
    
}
