let titulo = document.querySelector ("#titulo");
let campotexto = document.querySelector ("#campotexto")
let bttrocartexto = document.querySelector ("#bttrocartexto")
let btresetartexto = document.querySelector ("#btresetartexto")
  
    function alterarTexto(){
        //retirando o valor digitado no input
        //e jogando na variavel
        let textodigitado = campotexto.value;
        
        //Atribuindo ao elemento titulo o texto que foi digitado
        //No input
        titulo.textContent = textodigitado;
    } 
//atribuindo uma ação de clicar no botao
bttrocartexto.onclick = function (){
    alterarTexto(); 
}
    function resettexto(){
        let textoresetado = "Hello World !!";

        titulo.textContent = textoresetado;
    }
btresetartexto.onclick = function(){
    resettexto();
}